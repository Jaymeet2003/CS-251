#include <set>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include "driver.h"

using namespace std;

int main() {
    Person o1;
    o1.name = "Person O1";
    o1.scores['O'] = 1;
    Person o2;
    o2.name = "Person O2";
    o2.scores['O'] = 100;
    o2.scores['C'] = 1;
    set<Person> people;
    people.insert(o1);
    people.insert(o2);
    map <char, int> scores0;
    scores0['O'] = -1;
    Person x = mostSimilarTo(scores0, people);
    cout << x.name << endl;
    // ASSERT_EQ(mostSimilarTo(scores0, people), o2);
    map <char, int> scores1;
    scores1['O'] = -100;
    Person y = mostSimilarTo(scores1, people);
    cout << y.name << endl;
    // ASSERT_EQ(mostSimilarTo(scores1, people), o2);

}

