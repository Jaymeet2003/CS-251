// Author:  Jimmy Patel
// Date : 3rd July 2022

#include <math.h>
#include <limits>
#include <string>
#include <map>
#include <set>
#include "myrandom.h"

using namespace std;

constexpr double lowest_double = std::numeric_limits<double>::lowest();

/* Type: Question
 *
 * Type representing a personality quiz question.
 */
struct Question {
    string questionText;  // Text of the question
    map<char, int> factors;   // Map from factors to +1 or -1
    friend bool operator< (const Question& lhs, const Question& rhs) {
        return lhs.questionText < rhs.questionText;
    }
    friend bool operator== (const Question& lhs, const Question& rhs) {
        return lhs.questionText == rhs.questionText;
    }
    friend bool operator!= (const Question& lhs, const Question& rhs) {
        return lhs.questionText != rhs.questionText;
    }
};

/* Type: Person
 *
 * Type representing a person, used to represent people when determining
 * who's the closest match to the user.
 */
struct Person {
    string name;      // Name of the person
    map<char, int> scores;  // Map from factors to +1 or -1
    friend bool operator< (const Person& lhs,   const Person& rhs) {
        return lhs.name < rhs.name;
    }
    friend bool operator== (const Person& lhs, const Person& rhs) {
        return lhs.name == rhs.name;
    }
    friend bool operator!= (const Person& lhs, const Person& rhs) {
        return lhs.name != rhs.name;
    }
};

/* randomElement
 *
 * This function selects, at random, a Question from the inputted questions set
 * and returns the question.  Note, this function does not remove the randomly
 * selected question from the set.
*/
Question randomElement(set<Question>& questions) {
    int ind = randomInteger(0, (int)questions.size()-1);
    int i = 0;
    for (auto e : questions) {
        if (i == ind) {
            return e;
        }
        i++;
    }
    return {};
}

Question randomQuestionFrom(set<Question>& questions) {
    if (questions.size() == 0) {
        throw "Question set should not be empty";
    }
    // fetching random element
    Question que = randomElement(questions);
    // remove in set once fetch successfully
    questions.erase(que);
    return que;
}

map<char, int> scoresFrom(map<Question, int>& answers) {
    map<char, int> mapping;
    // iterate answers map and update character scores
    for (auto i = answers.begin(); i != answers.end(); i++) {
        Question que = i->first;
        for (auto j = que.factors.begin(); j != que.factors.end(); j++) {
            int diff = i->second - 3;
            mapping[j->first] += j->second * diff;
        }
    }
    return mapping;
}

map<char, double> normalize(map<char, int>& scores) {
    map<char, double> mapping;
    double norm = 0.0;
    // calculating normalize score
    for (auto i = scores.begin(); i != scores.end(); i++) {
        norm += i->second * i->second;
    }
    norm = sqrt(norm);
    // exception: Division by zero condition
    if (norm == 0.0) {
        throw "Division by zero condition!";
    }
    // calculating each charcter normalize score
    for (auto i = scores.begin(); i != scores.end(); i++) {
        mapping[i->first] = (i->second)*1.0 / norm;
    }
    return mapping;
}

double cosineSimilarityOf(const map<char, double>& lhs,
                          const map<char, double>& rhs) {
    double sim = 0.0;
    // calculating cosineSimilarityOf two person
    for (auto i = lhs.begin(); i != lhs.end(); i++) {
        for (auto j = rhs.begin(); j != rhs.end(); j++) {
            if (i->first == j->first) {
                sim += i->second * j->second * 1.0;
            }
        }
    }
    return sim;
}

Person mostSimilarTo(map<char, int>& scores, set<Person>& people) {
    if (people.size() == 0) {
        throw "set should not be empty";
    }
    double maxSim = -10000000000000;
    Person ans;
    // fetch normalize score
    map<char, double> lhs = normalize(scores);
    // iterate each people and evalute for most similiar person
    for (auto i = people.begin(); i != people.end(); i++) {
        Person p = *i;
        map<char, double> rhs = normalize(p.scores);
        double sim  = cosineSimilarityOf(lhs, rhs);
        // if similiar score higher then update value
        if (sim > maxSim) {
            maxSim = sim;
            ans = p;
        }
    }
    return ans;
}
