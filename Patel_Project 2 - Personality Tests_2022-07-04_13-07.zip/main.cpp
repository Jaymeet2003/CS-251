// Author:  Jimmy Patel
// Date : 3rd July 2022

#include <set>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include "driver.h"

using namespace std;

int main() {
    set<Question> questions;
    ifstream questionFile("questions.txt");
    string text;
    // parse questions file in to map
    while (getline (questionFile, text)) {
        Question que;
        int pos = text.find(". ");
        que.questionText = text.substr(0 , pos);
        string sub = text.substr(pos + 2);
        istringstream ss(sub);
        string word;
        map<char, int> factor;
        while (ss >> word) {
            int startIndex = 2;
            bool neg = false;
            // to check if negative value
            if (word[2] == '-') {
                neg = true;
                startIndex = 3;
            }
            int number = 0;
            for (int i = startIndex; i < (int)word.size(); i++) {
                number = number * 10 + (word[i] - '0');
            }
            if (neg == true) number = number * -1;
            factor[word[0]] = number;
        }
        que.factors = factor;
        questions.insert(que);
    }
    questionFile.close();

    // user interface
    cout << "Welcome to the Personality Quiz!" << endl << endl;
    cout << "Choose number of questions: ";

    int totalQuestions;

    cin >> totalQuestions;
    cout << endl;
    int answer;
    map<Question, int> scores;

    // user interface for quiz
    for (int i = 0; i < totalQuestions; i++) {
        cout << "How much do you agree with this statement?" << endl;
        Question que =  randomQuestionFrom(questions);
        cout << '"' << que.questionText << "." << '"' << endl << endl;
        cout << "1. Strongly disagree" << endl;
        cout << "2. Disagree" << endl;
        cout << "3. Neutral" << endl;
        cout << "4. Agree" << endl;
        cout << "5. Strongly agree" << endl << endl;
        cout << "Enter your answer here (1-5): ";
        cin >> answer;
        scores[que] = answer;
        cout << endl;
    }
    // get character score from question answers
    map<char, int> charScores = scoresFrom(scores);

    // mapping with all files
    map<int, string> peopleFileMapping;
    peopleFileMapping[1] = "BabyAnimals";
    peopleFileMapping[2] = "Brooklyn99";
    peopleFileMapping[3] = "Disney";
    peopleFileMapping[4] = "Hogwarts";
    peopleFileMapping[5] = "MyersBriggs";
    peopleFileMapping[6] = "SesameStreet";
    peopleFileMapping[7] = "StarWars";
    peopleFileMapping[8] = "Vegetables";
    peopleFileMapping[9] = "mine";

    // parse people file in to map
    while (true) {
        for (int i = 1; i <= 9; i++) {
            cout << i << ". " << peopleFileMapping[i] << endl;
        }
        cout << "0. To end program." << endl << endl;
        cout << "Choose test number (1-9, or 0 to end): ";
        int num;
        cin >> num;
        if (num == 0) {
            cout << "Goodbye!" << endl;
            break;
        }
        string filename = peopleFileMapping[num] + ".people";
        ifstream peopleFile(filename);
        set<Person> persons;
        while (getline(peopleFile, text)) {
            Person p;
            int pos = text.find(". ");
            p.name = text.substr(0 , pos);
            string sub = text.substr(pos + 2);
            istringstream ss(sub);
            string word;
            map<char, int> personScore;
            while (ss >> word) {
                int startIndex = 2;
                bool neg = false;
                // to check if negative value
                if (word[2] == '-') {
                    neg = true;
                    startIndex = 3;
                }
                int number = 0;
                for (int i = startIndex; i < (int)word.size(); i++) {
                    number = number * 10 + (word[i] - '0');
                }
                if (neg == true) number = number * -1;
                personScore[word[0]] = number;
            }
            p.scores = personScore;
            persons.insert(p);
        }
        // match similiar person using mostSimilarTo function
        Person x = mostSimilarTo(charScores, persons);
        cout << "You got " << x.name << "!"  << endl << endl;
    }
}