//
//  Project 1  - DNA Profiling
// TODO(Jimmy Patel): DNA profiling.
//
//

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

#include "ourvector.h"

using namespace std;

ourvector<ourvector<int>> dnaFreq;
ourvector<int> process;
ourvector<string> temp;
ourvector<string> temp1;
ourvector<string> name;
string dna = "";
string data;

// The function converts data from file to vectors.

ourvector<string> convertToVector(string data) {
  ourvector<string> result;
  string temp = "";
  for (int i = 0; i < (int)data.size(); i++) {
    if (data[i] == ',') {
      if (temp != "name") {
        result.push_back(temp);
      }
      temp = "";
    } else {
      temp += data[i];
    }
  }
  result.push_back(temp);
  return result;
}

// The function compares the dna

bool compareString(string dna, string x, int a, int b) {
  for (int i = a; i <= b; i++) {
    if (dna[i] != x[i - a]) {
      return false;
    }
  }
  return true;
}

// Finds the maximum mathes in DNA

int maxDnaMatch(string dna, string x) {
  int maximum = 0;
  int locMax = 0;

  for (int i = 0; i < (int)dna.size(); i++) {
    if (compareString(dna, x, i, i + x.size() - 1)) {
      locMax++;
      maximum = max(maximum, locMax);
      i = i + x.size() - 1;
    } else {
      locMax = 0;
    }
  }
  return maximum;
}


// loads the files

int load_db(string fileName) {
  cout << "Loading database..." << endl;
  ifstream inFile;

  inFile.open(fileName);
  if (!inFile.is_open()) {
    cout << "Error: unable to open \'" << fileName << "\'" << endl;
  }
  getline(inFile, data);
  temp1.clear();
  temp1 = convertToVector(data);
  dnaFreq.clear();
  name.clear();
  process.clear();

  while (getline(inFile, data)) {
    temp = convertToVector(data);
    ourvector<int> frequency;
    for (int i = 0; i < temp.size(); i++) {
      if (i == 0) {
        name.push_back(temp[i]);
        continue;
      }
      frequency.push_back(stoi(temp[i]));
    }
    dnaFreq.push_back(frequency);
  }
  return 0;
}


// displays the output
void display() {
  if (name.size() <= 0) {
    cout << "No database loaded." << endl;
  } else {
    cout << "Database loaded: " << endl;
    for (int i = 0; i < (int)name.size(); i++) {
      cout << name[i] << " ";
      for (int j = 0; j < (int)temp1.size(); j++) {
        cout << dnaFreq[i][j];
        if (j != temp1.size() - 1) {
          cout << " ";
        }
      }
      cout << endl;
    }
    cout << endl;
  }

  if (dna == "") {
    cout << "No DNA loaded." << endl;
  } else {
    cout << "DNA loaded: " << endl;
    cout << dna << endl;
  }

  if (process.size() <= 0) {
    cout << endl << "No DNA has been processed." << endl;
  } else {
    cout << endl << "DNA processed, STR counts: " << endl;
    for (int i = 0; i < (int)temp1.size(); i++) {
      cout << temp1[i] << ": ";
      cout << process[i] << endl;
    }
    cout << endl;
  }
}


//loads dna file

void load_dna(string fileName) {
  cout << "Loading DNA..." << endl;
  ifstream inFile;

  inFile.open(fileName);
  if (!inFile.is_open()) {
    cout << "Error: unable to open \'" << fileName << "\'" << endl;
  }
  process.clear();
  getline(inFile, dna);
}

//processes dna

int process_dna() {
  if (name.size() <= 0) {
    cout << "No database loaded." << endl;
    return 0;
  }
  if (dna == "") {
    cout << "No DNA loaded." << endl;
    return 0;
  }
  cout << "Processing DNA..." << endl;

  for (int i = 0; i < (int)temp1.size(); i++) {
    process.push_back(maxDnaMatch(dna, temp1[i]));
  }

  return 0;
}

// searching for dna

int search() {
  if (name.size() <= 0) {
    cout << "No database loaded." << endl;
    return 0;
  }
  if (dna == "") {
    cout << "No DNA loaded." << endl;
    return 0;
  }
  if (process.size() <= 0) {
    cout << "No DNA processed." << endl;
    return 0;
  }
  cout << "Searching database..." << endl;

  bool flag;

  for (int i = 0; i < (int)name.size(); i++) {
    int j;
    for (j = 0; j < process.size(); j++) {
      if (process[j] != dnaFreq[i][j]) {
        break;
      }
    }
    if (j == process.size()) {
      flag = true;
      cout << "Found in database!  DNA matches: " << name[i] << endl;
      break;
    }
  }
  if (flag == false) {
    cout << "Not found in database." << endl;
  }

  return 0;
}

//Testing



void test(string file_db, string file_dna) {
  load_db(file_db);
  display();
  load_dna(file_dna);
  display();
  process_dna();
  display();
  search();
}

// Menu for selection of task

void menu() {
  cout << "Enter command or # to exit: ";
  string str;
  getline(cin, str);
  stringstream ss(str);
  string command;
  string fileName;
  string dna_fileName;
  ss >> command >> fileName >> dna_fileName;

  bool flag = true;

  if (command == "load_db") {
    load_db(fileName);
    menu();
  } else if (command == "display") {
    display();
    menu();
  } else if (command == "load_dna") {
    load_dna(fileName);
    menu();
  } else if (command == "process") {
    process_dna();
    menu();
  } else if (command == "search") {
    search();
    menu();
  } else if (command == "#") {
    exit(0);
  } else if (command == "test") {
    test(fileName, dna_fileName);
    menu();
  } else {
    cout << "Invalid choice! Try again" << endl;
    menu();
  }
}

// main function

int main() {
  cout << "Welcome to the DNA Profiling Application." << endl;
  menu();
  return 0;
}